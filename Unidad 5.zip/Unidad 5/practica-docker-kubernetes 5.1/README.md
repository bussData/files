
---

## 🎯 Objetivo General de la Práctica 5.1

**Comprender y aplicar volúmenes en Kubernetes** para lograr **persistencia de datos** dentro de los Pods. En Kubernetes, cuando un Pod muere, su sistema de archivos efímero desaparece también. Para resolver esto, Kubernetes ofrece varios tipos de volúmenes, que permiten que los datos **sobrevivan a la eliminación del Pod**. Esta práctica te capacita para:

- Montar volúmenes locales del host.
- Crear volúmenes persistentes administrados por Kubernetes (PV).
- Solicitar almacenamiento dinámico a través de PVCs.
- Comprobar la persistencia de datos incluso tras reiniciar un Pod.

---

## 🔬 Paso 1: Configurar un volumen `hostPath`

### 🧠 ¿Qué es un volumen `hostPath`?

Un volumen `hostPath` permite a un Pod acceder directamente al **sistema de archivos del nodo donde está ejecutándose**. Es útil para pruebas, almacenamiento local de logs o comunicación entre contenedores que compartan un directorio del host.

### 📄 Contenido del archivo `hostpath-pod.yaml`:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: hostpath-pod
spec:
  containers:
    - name: nginx
      image: nginx
      volumeMounts:
        - mountPath: /usr/share/nginx/html
          name: host-volume
  volumes:
    - name: host-volume
      hostPath:
        path: /data/nginx
        type: DirectoryOrCreate
```

### 🧩 Explicación paso a paso:

- `apiVersion: v1` → versión estable de la API de Kubernetes para Pods.
- `kind: Pod` → indica que estamos creando un Pod.
- `metadata.name` → nombre del Pod.
- `containers.image: nginx` → usaremos la imagen oficial de NGINX.
- `volumeMounts.mountPath` → punto dentro del contenedor donde se montará el volumen (`/usr/share/nginx/html` es donde NGINX sirve su contenido web).
- `volumes.hostPath.path` → indica que vamos a montar el directorio `/data/nginx` del nodo.
- `type: DirectoryOrCreate` → si la ruta no existe en el host, se creará automáticamente como directorio.

### 🧪 Aplicamos el recurso:

```bash
kubectl apply -f hostpath-pod.yaml
```

**¿Qué hace este comando?**
- Instruye a Kubernetes para que **cree el Pod descrito en el archivo YAML**.
- Si `/data/nginx` no existe en el nodo, se crea y se monta.

---

## 🔁 Paso 2: Crear un `PersistentVolume` (PV) y un `PersistentVolumeClaim` (PVC)

### 🧠 ¿Qué es un PersistentVolume?

Es una **unidad de almacenamiento del clúster**. Puede ser local (como en este caso) o remoto (como EBS, NFS, AzureDisk, etc.).

### 🧠 ¿Qué es un PersistentVolumeClaim?

Es una **solicitud por parte de un usuario o Pod** para acceder a almacenamiento con ciertas características (como tamaño, acceso de lectura/escritura).

---

### 📄 Archivo `persistent-volume.yaml`:

```yaml
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-volume
spec:
  capacity:
    storage: 1Gi
  accessModes:
    - ReadWriteOnce
  hostPath:
    path: "/mnt/data"
```

**Explicación:**
- `storage: 1Gi` → define el tamaño del volumen.
- `ReadWriteOnce` → solo un nodo puede montar este volumen en modo lectura/escritura a la vez.
- `hostPath.path` → este volumen utilizará el directorio `/mnt/data` del nodo.

---

### 📄 Archivo `persistent-volume-claim.yaml`:

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: pvc-volume
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
```

**Explicación:**
- El `PVC` está solicitando 1Gi con el mismo `accessMode` que el `PV`, por lo tanto, **Kubernetes podrá enlazarlos automáticamente** si son compatibles.

---

### ⚙️ Aplicamos los recursos:

```bash
kubectl apply -f persistent-volume.yaml
kubectl apply -f persistent-volume-claim.yaml
```

### 🔍 Verificamos que estén enlazados:

```bash
kubectl get pv
kubectl get pvc
kubectl describe pvc pvc-volume
```

🔎 **Esperamos que el estado de ambos sea `Bound`**. Si el PVC queda en `Pending`, indica que no encontró un volumen compatible.

---

## 📦 Paso 3: Crear un Pod que use el PVC

### 📄 Archivo `pvc-pod.yaml`:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: pvc-pod
spec:
  containers:
    - name: busybox
      image: busybox
      command: [ "sleep", "3600" ]
      volumeMounts:
        - mountPath: "/mnt/data"
          name: pvc-volume
  volumes:
    - name: pvc-volume
      persistentVolumeClaim:
        claimName: pvc-volume
```

### 🔍 Detalles importantes:

- Utiliza la imagen `busybox`, ligera y útil para pruebas.
- Ejecuta el comando `sleep 3600` → se mantiene vivo por 1 hora.
- El volumen `pvc-volume` está **asociado al PVC** `pvc-volume`, montado en `/mnt/data`.

### ⚙️ Aplicación:

```bash
kubectl apply -f pvc-pod.yaml
```

---

## 🧪 Paso 4: Verificar la persistencia de datos

### 🛠️ Ejecutamos comandos dentro del contenedor:

```bash
kubectl exec -it pvc-pod sh
```

Dentro del contenedor:

```bash
echo "Hola desde el volumen persistente!" > /mnt/data/hola.txt
cat /mnt/data/hola.txt
```

✔️ Confirmamos que el archivo se guardó correctamente.

### 🔁 Eliminamos el Pod y lo volvemos a crear:

```bash
kubectl delete pod pvc-pod
kubectl apply -f pvc-pod.yaml
```

### 🔍 Volvemos a ingresar al contenedor:

```bash
kubectl exec -it pvc-pod -- /bin/sh
ls -l /mnt/data
cat /mnt/data/hola.txt
```

✅ **El archivo debe seguir allí**, demostrando que el volumen montado **mantiene los datos entre reinicios del Pod.**

---

## 🧹 Paso 5: Limpieza (si es necesario)

```bash
kubectl delete pod pvc-pod --ignore-not-found
kubectl delete pvc pvc-volume --ignore-not-found
kubectl delete pv pv-volume --ignore-not-found
kubectl delete pod hostpath-pod --ignore-not-found
```

