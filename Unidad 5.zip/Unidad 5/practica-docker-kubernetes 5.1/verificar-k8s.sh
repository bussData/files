#!/bin/bash

echo "Verificando contexto actual de Kubernetes..."
kubectl config current-context || echo "No se pudo obtener el contexto actual"

echo "Verificando todos los contextos disponibles..."
kubectl config get-contexts || echo "No hay contextos disponibles"

echo "Verificando nodos activos (si hay conexión)..."
kubectl get nodes || echo "No se puede acceder al clúster actual"

echo "Verificando versión de Kubernetes..."
kubectl version --client=true
