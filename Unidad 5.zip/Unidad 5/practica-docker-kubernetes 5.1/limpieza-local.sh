#!/bin/bash

echo "Eliminando Pod pvc-pod (si existe)..."
kubectl delete pod pvc-pod --ignore-not-found

echo "Eliminando PVC pvc-volume..."
kubectl delete pvc pvc-volume --ignore-not-found

echo "Eliminando PV pv-volume..."
kubectl delete pv pv-volume --ignore-not-found

echo "Eliminando Pod hostpath-pod (si existe)..."
kubectl delete pod hostpath-pod --ignore-not-found

echo "Limpieza finalizada. Puedes volver a aplicar tus YAMLs."
