
---

## Objetivo de la Práctica

El propósito principal de esta práctica es implementar un **DaemonSet** en Kubernetes para garantizar que se despliegue un pod especializado en **cada nodo** o en nodos específicos del clúster. Este mecanismo es muy útil en escenarios donde se requiere que ciertos servicios (como agentes de monitoreo, logging, o cualquier servicio a nivel de sistema) se ejecuten de forma consistente en todos los nodos, asegurando así la homogeneidad y la disponibilidad de dichos servicios en toda la infraestructura.

El DaemonSet permite que, al crearse o añadirse nuevos nodos al clúster, automáticamente se despliegue el pod deseado en ellos. Además, se puede restringir la ejecución a determinados nodos mediante etiquetas y selectores, lo que añade flexibilidad a la gestión de recursos.  


---

## Paso 1: Verificar el Estado de los Nodos del Clúster

Antes de desplegar cualquier recurso, es crucial confirmar que el clúster cuente con la cantidad esperada de nodos. En esta práctica se requiere tener al menos dos nodos.

**Comando:**

```bash
kubectl get nodes
```

**Explicación:**

- Este comando lista todos los nodos del clúster y muestra su estado (por ejemplo, Ready, NotReady, etc.).
- Verificar el estado es importante para asegurarse de que los pods se puedan desplegar sin problemas y que la infraestructura esté en condiciones óptimas.

---

## Paso 2: Crear el Archivo YAML para el DaemonSet

Aquí se define el recurso DaemonSet que gestionará la creación del pod en cada nodo. Usaremos un contenedor basado en la imagen **nginx:latest** como ejemplo.

**Archivo: `daemonset-example.yaml`**

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: specialized-daemonset
  labels:
    app: specialized
spec:
  selector:
    matchLabels:
      app: specialized
  template:
    metadata:
      labels:
        app: specialized
    spec:
      containers:
      - name: specialized-container
        image: nginx:latest
        ports:
        - containerPort: 80
      tolerations:
      - key: "node-role.kubernetes.io/master"
        effect: "NoSchedule"
```

**Explicación de los elementos clave:**

- **apiVersion y kind:**  
  Especifica que se está creando un recurso de tipo **DaemonSet** usando la API `apps/v1`.

- **metadata:**  
  Define el nombre y etiquetas del DaemonSet, lo que es útil para la identificación y selección posterior.

- **spec.selector:**  
  Utiliza etiquetas para emparejar los pods creados por el DaemonSet. Es importante que el selector coincida con las etiquetas definidas en la plantilla del pod.

- **template:**  
  Contiene la especificación del pod que se desplegará en cada nodo. Aquí se define el contenedor (nombre, imagen, puertos, etc.).

- **tolerations:**  
  Permite que el pod se ejecute en nodos que tienen taints, como suele ser el nodo maestro. Por defecto, Kubernetes no programa pods en el nodo maestro, pero añadiendo esta tolerancia se indica que el pod puede ejecutarse allí.  
  citeturn0file0

---

## Paso 3: Aplicar el DaemonSet en el Clúster

Una vez creado el archivo YAML, se debe aplicar en el clúster para que Kubernetes lo procese y despliegue los pods en cada nodo.

**Comando:**

```bash
kubectl apply -f daemonset-example.yaml
```

**Explicación:**

- Este comando envía la configuración definida en el archivo YAML al servidor API de Kubernetes.
- Kubernetes crea el recurso DaemonSet y comienza el proceso de despliegue en todos los nodos que cumplan con los requisitos (incluyendo la tolerancia definida para el nodo maestro).

---

## Paso 4: Verificar el Estado del DaemonSet

Después de aplicar el DaemonSet, es importante comprobar que se haya desplegado correctamente.

**Comando:**

```bash
kubectl get daemonset specialized-daemonset
```

**Explicación:**

- La salida mostrará información como:
  - **DESIRED:** Número de pods esperados (por ejemplo, uno por nodo).
  - **CURRENT:** Número de pods actualmente gestionados por el DaemonSet.
  - **READY:** Número de pods que han alcanzado el estado Ready y están disponibles para manejar tráfico.
  - **UP-TO-DATE:** Cantidad de pods actualizados con la última especificación.
  - **AVAILABLE:** Número de pods que están disponibles.
- Una correcta salida esperada podría mostrar DESIRED: 3, CURRENT: 3, pero podrías notar que READY o AVAILABLE varían en función del tiempo de inicio de los contenedores.  
 

---

## Paso 5: Verificar los Pods Desplegados en Cada Nodo

Para asegurarse de que el DaemonSet ha desplegado un pod en cada nodo, se utiliza un comando que filtra por la etiqueta definida.

**Comando:**

```bash
kubectl get pods -o wide -l app=specialized
```

**Explicación:**

- El flag `-o wide` extiende la salida para incluir información adicional, como el nodo en el que se está ejecutando cada pod.
- El flag `-l app=specialized` filtra la lista de pods para mostrar únicamente aquellos creados por nuestro DaemonSet.
- Esta salida te permite verificar que cada nodo tiene asignado su pod, confirmando el funcionamiento correcto del DaemonSet.  
  citeturn0file0

---

## Paso 6 (Opcional): Limitar el DaemonSet a Nodos Específicos

En algunos escenarios se desea que el DaemonSet se ejecute únicamente en nodos con características específicas, por ejemplo, solo en nodos de trabajo.

### 6.1 Etiquetar el Nodo

Primero, se debe etiquetar el nodo deseado:

```bash
kubectl label nodes worker-node1 deploy=specialized
```

**Explicación:**

- Este comando añade la etiqueta `deploy=specialized` al nodo `worker-node1`, marcándolo para que reciba el pod del DaemonSet.

### 6.2 Actualizar el Archivo YAML con un nodeSelector

Crea o actualiza un archivo YAML (por ejemplo, `daemonset-example2.yaml`) para incluir el selector de nodos:

```yaml
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: specialized-daemonset
  labels:
    app: specialized
spec:
  selector:
    matchLabels:
      app: specialized
  template:
    metadata:
      labels:
        app: specialized
    spec:
      nodeSelector:
        deploy: specialized
      containers:
      - name: specialized-container
        image: nginx:latest
        ports:
        - containerPort: 80
```

**Explicación:**

- **nodeSelector:**  
  Se agrega esta sección para que Kubernetes programe el pod únicamente en nodos que tengan la etiqueta `deploy=specialized`. Esto restringe la ejecución del DaemonSet a nodos específicos, en lugar de desplegarlo en todos los nodos del clúster.

### 6.3 Eliminar y Reaplicar la Configuración

Para actualizar el DaemonSet, se debe eliminar la configuración anterior y aplicar la nueva:

```bash
kubectl delete -f daemonset-example.yaml
kubectl apply -f daemonset-example2.yaml
```

**Explicación:**

- El primer comando elimina el DaemonSet anterior.
- El segundo comando aplica la nueva configuración que incluye el `nodeSelector`, limitando la ejecución a los nodos etiquetados.

---

## Paso 7: Verificar la Ejecución en Nodos Seleccionados

Finalmente, verifica que el DaemonSet se ejecute únicamente en los nodos que tienen la etiqueta específica.

**Comando:**

```bash
kubectl get pods -o wide -l app=specialized
```

**Explicación:**

- La salida deberá mostrar que los pods están desplegados solamente en el nodo (o nodos) etiquetados con `deploy=specialized`.
- Este paso es esencial para confirmar que la restricción mediante `nodeSelector` se ha aplicado correctamente.  
 

---

## Resultados Esperados y Salida

Según las instrucciones, se esperan los siguientes resultados y salidas:

- **Captura de pantalla del estado del clúster:**  
  Se debe visualizar que hay tres nodos (por ejemplo, tres nodos de trabajo y un nodo maestro) en estado **Ready**.

- **Contenido del archivo YAML:**  
  Una captura mostrando el contenido del archivo `daemonset-example.yaml`.

- **Estado del DaemonSet antes y después de su creación:**  
  La salida del comando `kubectl get daemonset specialized-daemonset` indicará:
  - **DESIRED:** 3 (indicando que se espera un pod por cada nodo)
  - **CURRENT:** 3 (los pods han sido creados)
  - **READY:** 1 (el primer pod ha alcanzado el estado Ready, aunque se irán poniendo en Ready progresivamente)
  - **UP-TO-DATE:** 3
  - **AVAILABLE:** 1 (puede variar en función del tiempo de espera)
  - **NODE SELECTOR:** <none> en la primera configuración.

- **Verificación de los pods desplegados:**  
  Una captura mostrando la salida del comando `kubectl get pods -o wide -l app=specialized`, en la que se visualiza en qué nodo se está ejecutando cada pod.

- **Resultados tras aplicar el nodeSelector (archivo daemonset-example2.yaml):**  
  Se deberá observar que el DaemonSet se despliega únicamente en los nodos con la etiqueta `deploy=specialized`, lo que confirmará la correcta aplicación de la restricción.

Cada uno de estos resultados se visualiza en las capturas de pantalla adjuntas en el documento original, lo que permite comparar la salida real del clúster con la salida esperada para validar la correcta implementación de la práctica.  

---

### Eliminando el DaemonSet

Si has desplegado el DaemonSet utilizando el archivo `daemonset-example.yaml`, puedes eliminarlo con el siguiente comando:

```bash
kubectl delete -f daemonset-example.yaml
```

Si, en cambio, has aplicado la configuración actualizada con el archivo `daemonset-example2.yaml` (donde se especifica un nodeSelector), entonces elimina ese recurso usando:

```bash
kubectl delete -f daemonset-example2.yaml
```

Estos comandos envían una solicitud a Kubernetes para que elimine el recurso DaemonSet junto con los pods asociados.

### Eliminando el DaemonSet por nombre

Alternativamente, puedes eliminar el recurso especificando su tipo y nombre, por ejemplo:

```bash
kubectl delete daemonset specialized-daemonset
```

Esto es especialmente útil si deseas eliminar el recurso sin tener el archivo YAML a mano.

### Consideraciones adicionales

- **Etiquetas en los nodos:**  
  Si has aplicado etiquetas a los nodos (por ejemplo, con `kubectl label nodes docker-desktop deploy=specialized`), estas etiquetas permanecerán en el nodo a menos que las elimines explícitamente. Para quitar una etiqueta de un nodo, puedes usar:

  ```bash
  kubectl label nodes docker-desktop deploy-
  ```

- **Verificar la eliminación:**  
  Una vez eliminados los recursos, es recomendable verificar que ya no se encuentren en el clúster. Puedes hacerlo con comandos como:

  ```bash
  kubectl get daemonset
  kubectl get pods -l app=specialized
  ```


---

## Conclusión

Al finalizar la práctica 5.5, habrás logrado:
- Desplegar un DaemonSet que garantiza la ejecución de un pod (en este caso, un contenedor Nginx) en **todos los nodos** del clúster o en nodos específicos según la configuración.
- Comprender el uso de tolerations para permitir la ejecución en nodos con taints (como el nodo maestro).
- Aplicar técnicas avanzadas de etiquetado y uso de **nodeSelector** para restringir la programación de pods a nodos determinados.
- Verificar y validar la configuración mediante comandos de Kubernetes y compararla con el resultado esperado.

Esta práctica es fundamental para la administración avanzada de Kubernetes, ya que demuestra cómo se puede automatizar la distribución de cargas específicas en cada nodo de un clúster, optimizando la disponibilidad y la gestión de recursos en entornos de producción. 

