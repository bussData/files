# Práctica 5.3 – Kubernetes Ingress 

## 0. Introducción y Conceptos Clave

Esta práctica introduce varios conceptos importantes para el uso eficiente de Kubernetes. Antes de comenzar, revisa estos conceptos clave:

| Concepto | Explicación sencilla | Ejemplo práctico |
|----------|----------------------|------------------|
| **Ingress Controller** | Es como la recepcionista de una empresa. Cuando llega un visitante (tráfico externo), ella sabe exactamente hacia qué departamento (aplicación interna) dirigirlo según la solicitud que trae (nombre del dominio o ruta URL). | Recibir peticiones para `app1.example.com` y enviarlas solo a la aplicación App1. |
| **Ingress Resource** | Es la agenda de la recepcionista, donde están anotadas claramente las instrucciones sobre qué hacer con cada visitante, según quién sea o qué venga buscando (host o ruta específica). | Si visitas `app1.example.com`, el Ingress sabe exactamente a qué servicio interno (App1) redirigir la solicitud. |
| **Service (ClusterIP)** | Es similar a una extensión telefónica interna. Solo puedes llamarla dentro de la empresa (dentro del clúster), no desde fuera directamente. | App1 está disponible en la IP interna `10.105.9.54` solo dentro del clúster. |
| **NodePort vs LoadBalancer** | NodePort abre una puerta específica en cada edificio (nodo) accesible desde afuera, mientras LoadBalancer es un guardia que dirige automáticamente el tráfico externo hacia adentro. | NodePort es útil para pruebas locales; LoadBalancer es ideal en nubes públicas. |
| **Port-forwarding** | Establece una línea directa temporal a una extensión interna para acceder fácilmente desde fuera del edificio. | Acceder directamente a App1 en tu navegador usando `localhost:8080`. |

## 1. Objetivo de la Práctica

En esta práctica aprenderás cómo exponer múltiples aplicaciones HTTP dentro de un clúster Kubernetes usando un solo punto de entrada—el **Ingress Controller**. Comprenderás:

1. **El rol de un Ingress Controller**.
2. **Reglas de enrutamiento basadas en host y path**.
3. **Buenas prácticas** para entornos locales vs. nube.
4. **Diagnóstico de problemas comunes** (p.ej. `EXTERNAL-IP <pending>`).

> **Meta‑habilidad:** Al finalizar, podrás diseñar puertas de enlace HTTP capaces de versionar microservicios y aplicar políticas de seguridad como *rate‑limiting* o *mTLS*.


## 1. Instalación del Ingress Controller

### 1.1 ¿Por qué necesitamos un Ingress Controller?

- Un **Service** de tipo `ClusterIP` solo es accesible dentro del clúster.
- Un `NodePort` abre un puerto en **cada** nodo; escala mal y expone muchos puntos de ataque.
- Un `LoadBalancer` crea un balanceador por servicio—costoso en nube y caótico en *on‑prem*.

El **Ingress Controller** actúa como **reverse proxy** + **load balancer** + **router**.  Todo el tráfico externo entra por él y se redistribuye según reglas declarativas (`Ingress` objects).

### 1.2 Instalación de NGINX Ingress Controller

```bash
kubectl apply -f \
  https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/cloud/deploy.yaml
```

**Desglose del comando**

| Fragmento       | Significado                                                                                  |
| --------------- | -------------------------------------------------------------------------------------------- |
| `kubectl apply` | Aplica manifiestos idempotentemente.                                                         |
| `-f`            | Indica que el origen es un archivo o URL.                                                    |
| URL             | Manifiesto oficial que crea *Namespace*, *ServiceAccount*, *RBAC*, *Deployment* y *Service*. |

> **Tip académico:** Prefiere `apply` sobre `create`; así podrás re‑aplicar cambios sin borrar recursos.

### 1.3 Verificación del controlador

```bash
kubectl get pods -n ingress-nginx
```

Salida esperada (ejemplo):

```
NAME                                       READY   STATUS      RESTARTS   AGE
ingress-nginx-admission-create-ph2pf       0/1     Completed   0          3m12s
ingress-nginx-admission-patch-8grpm        0/1     Completed   0          3m12s
ingress-nginx-controller-97689b66d-8qg4w   1/1     Running     0          3m12s
```

- **READY 1/1** indica que el contenedor del *controller* superó las *probes*.
- Si ves `CrashLoopBackOff`, inspecciona los logs: `kubectl logs <pod> -n ingress-nginx`.

---

### 1.4 ¿Por qué aparecen tres pods en *ingress-nginx*?

Cuando aplicas el manifiesto oficial, Kubernetes crea **un Deployment y dos Jobs**:

| Recurso | Nombre típico | Propósito |
|---------|---------------|-----------|
| Job     | `ingress-nginx-admission-create-<hash>` | Genera el certificado TLS y el Secret que usará el _webhook_ de admisión para validar/convertir recursos Ingress. Se ejecuta **una sola vez** y finaliza en `Completed`. |
| Job     | `ingress-nginx-admission-patch-<hash>` | Parchea el Deployment del controller con el certificado generado, inyectando la configuración necesaria para que el _webhook_ funcione. También termina en `Completed`. |
| Deployment | `ingress-nginx-controller-<hash>` | El pod principal que actúa como reverse‑proxy y load balancer para tus reglas Ingress. Permanece en `Running`. |

> **¿Por qué tardaron ~3 min?**
>
> 1. **Descarga de la imagen** `k8s.gcr.io/ingress-nginx/controller:<tag>`: en entornos con ancho de banda limitado puede tomar un par de minutos.
> 2. **Generación y firma de certificados**: los Jobs deben esperar a que el _API server_ reconozca el Secret antes de parchear el Deployment.
> 3. **Readiness probes**: el controller no pasa a `READY 1/1` hasta que NGINX arranca y la sonda HTTP responde 200.

Ahora continuemos con el despliegue de las aplicaciones de prueba.

## 2. Despliegue de las aplicaciones de prueba

### 2.1 Creación de Namespaces

```bash
kubectl create namespace app1
kubectl create namespace app2
```

Los **namespaces** aíslan recursos lógicamente y permiten cuotas de recursos o políticas de red diferenciadas.

### 2.2 Deployments

El contenedor `hashicorp/http-echo` devuelve el texto pasado en `args`; ideal para pruebas.

```yaml
# app1-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app1
  namespace: app1
spec:
  replicas: 2                  # Alta disponibilidad mínima
  selector:
    matchLabels:
      app: app1
  template:
    metadata:
      labels:
        app: app1
    spec:
      containers:
      - name: app1
        image: hashicorp/http-echo
        args: ["-text=Hello from App1"]
        ports:
        - containerPort: 5678
```

> **Por qué 5678?** Puerto arbitrario para evitar colisiones con servicios comunes.

```yaml
# app2-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app2
  namespace: app2
spec:
  replicas: 2
  selector:
    matchLabels:
      app: app2
  template:
    metadata:
      labels:
        app: app2
    spec:
      containers:
      - name: app2
        image: hashicorp/http-echo
        args: ["-text=Hello from App2"]
        ports:
        - containerPort: 5678
```

> **Por qué 5678?** Puerto arbitrario para evitar colisiones con servicios comunes.

### 2.3 Services (ClusterIP)

#### 2.3.1 Service para *app1*

```yaml
# app1-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: app1-service
  namespace: app1
spec:
  selector:
    app: app1
  ports:
  - port: 80           # Puerto virtual que verá el Ingress
    targetPort: 5678   # Puerto real en el contenedor
  type: ClusterIP
```

#### 2.3.2 Service para *app2*

```yaml
# app2-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: app2-service
  namespace: app2
spec:
  selector:
    app: app2
  ports:
  - port: 80
    targetPort: 5678
  type: ClusterIP
```

### 2.4 Aplicación de manifiestos

```bash
kubectl apply -f app1-deployment.yaml -f app1-service.yaml \
              -f app2-deployment.yaml -f app2-service.yaml
```

Comprobación:

```bash
kubectl get pods -n app1
kubectl get svc  -n app1
```

Salida de ejemplo para los Pods y el Service:

```bash
# kubectl get pods -n app1
NAME                    READY   STATUS    RESTARTS   AGE
app1-746b98b475-cbcvw   1/1     Running   0          17s
app1-746b98b475-h676n   1/1     Running   0          17s

# kubectl get svc -n app1
NAME           TYPE        CLUSTER-IP    EXTERNAL-IP   PORT(S)   AGE
app1-service   ClusterIP   10.105.9.54   <none>        80/TCP    25s
```

**¿Qué hace `kubectl get svc`?**

`svc` es un alias de **Service**. El comando lista todos los objetos `Service` del namespace indicado y muestra información clave:

- **TYPE** – Estrategia de exposición (`ClusterIP`, `NodePort`, `LoadBalancer`, etc.).
- **CLUSTER-IP** – IP virtual interna que balancea el tráfico hacia los Pods seleccionados por el Service.
- **PORT(S)** – Puertos expuestos (virtual → container).
- **EXTERNAL-IP** – IP pública asignada por el proveedor o `<none>` si el Service no está expuesto externamente.

En este ejemplo, `app1-service` es de tipo `ClusterIP`; por tanto solo es accesible dentro del clúster y servirá como backend para el Ingress.


---

## 3. Configuración del recurso Ingress

### 3.1 Anatomía de un Ingress

- `ingressClassName`: vincula la regla al *controller* específico (NGINX en este caso).
- `rules`: lista de **hosts** y **paths** que definen cómo enrutar el tráfico.
- Anotaciones NGINX (`nginx.ingress.kubernetes.io/*`) habilitan funciones como re‑escritura de URLs, TLS, rate‑limit, etc.

### 3.2 Manifiestos

#### 3.2.1 Ingress para *app1*

**Archivo:** `app1-ingress.yaml`

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: app1-ingress
  namespace: app1
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  rules:
  - host: app1.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: app1-service
            port:
              number: 80
```

#### 3.2.2 Ingress para *app2*

**Archivo:** `app2-ingress.yaml`

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: app2-ingress
  namespace: app2
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  ingressClassName: nginx
  rules:
  - host: app2.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: app2-service
            port:
              number: 80
```

### 3.3 Aplicar y verificar

```bash
kubectl apply -f app1-ingress.yaml -f app2-ingress.yaml
kubectl get ingress --all-namespaces

# Describir cada recurso Ingress para inspeccionar reglas y endpoints
kubectl describe ingress app1-ingress -n app1
kubectl describe ingress app2-ingress -n app2
```

Salida típica:

```
NAMESPACE   NAME           CLASS   HOSTS               ADDRESS   PORTS   AGE
app1        app1-ingress   nginx   app1.example.com    80        20s
app2        app2-ingress   nginx   app2.example.com    80        20s
```

> **ADDRESS** puede estar vacío; depende de que el Service del controller tenga IP externa.

---

## 4. Pruebas de enrutamiento

### 4.1 Obtener IP o NodePort del controller

```bash
kubectl get svc -n ingress-nginx
```

Salida de ejemplo:

```
NAME                                 TYPE           CLUSTER-IP     EXTERNAL-IP   PORT(S)                          AGE
ingress-nginx-controller             LoadBalancer   10.99.17.229   localhost     80:31156/TCP,443:31258/TCP      38m
ingress-nginx-controller-admission   ClusterIP      10.111.65.52   <none>        443/TCP                         38m
```

**Interpretación rápida**

- `TYPE` **LoadBalancer** con **EXTERNAL-IP = localhost** indica que tu clúster (por ejemplo *kind* o *minikube*) utiliza un _load‑balancer_ basado en loopback para exponer el servicio a la máquina anfitriona.
- El formato `80:31156/TCP` significa **<PORT>:<NODEPORT>**; es decir, el Ingress escuchará externamente en **31156** (HTTP) y **31258** (HTTPS).

#### 4.1.1 Describir el Service

Para profundizar en la configuración y ver los *endpoints* reales ejecuta:

```bash
kubectl describe svc ingress-nginx-controller -n ingress-nginx
```

En la salida observa:

- **Endpoints:** IP:port de cada pod del controller.
- **Annotations / Selector:** Cómo Kubernetes enruta el tráfico.

*Si `EXTERNAL-IP` aparece como `<pending>`*, significa que tu entorno local no soporta *LoadBalancer* automático.

#### 4.1.2 Cambiar el Service a **NodePort**

1. **Editar el Service** para modificar el tipo:

   ```bash
   kubectl edit svc ingress-nginx-controller -n ingress-nginx
   ```
   Cambia `type: LoadBalancer` → `type: NodePort` y guarda.

2. **Verificar los cambios** y obtener el nuevo `NODE_PORT`:

   ```bash
   kubectl get svc ingress-nginx-controller -n ingress-nginx
   ```

3. **Probar de nuevo con `curl`** usando la IP del nodo y el `NODE_PORT` asignado.

### 4.2 Curl con encabezado Host Curl con encabezado Host

```bash
# kubectl get svc -n ingress-nginx
NAME                                 TYPE           CLUSTER-IP     EXTERNAL-IP   PORT(S)                              AGE
ingress-nginx-controller             LoadBalancer   10.99.17.229   localhost     80:31156/TCP,443:31258/TCP           38m
ingress-nginx-controller-admission   ClusterIP      10.111.65.52   <none>        443/TCP                             38m
```

En este clúster (por ejemplo, _kind_ o _minikube_), el controlador se expone como `LoadBalancer` pero con `EXTERNAL-IP` = **localhost**; los puertos `31156` y `31258` son los NodePorts asignados para HTTP y HTTPS respectivamente.

#### 4.1.1 Descripción detallada del Service

```bash
kubectl describe svc ingress-nginx-controller -n ingress-nginx
Name:                     ingress-nginx-controller
Namespace:                ingress-nginx
Labels:                   app.kubernetes.io/component=controller
                          app.kubernetes.io/instance=ingress-nginx
                          app.kubernetes.io/name=ingress-nginx
                          app.kubernetes.io/part-of=ingress-nginx
                          app.kubernetes.io/version=1.12.1
Annotations:              <none>
Selector:                 app.kubernetes.io/component=controller,app.kubernetes.io/instance=ingress-nginx,app.kubernetes.io/name=ingress-nginx
Type:                     LoadBalancer
IP Family Policy:         SingleStack
IP Families:              IPv4
IP:                       10.99.17.229
IPs:                      10.99.17.229
LoadBalancer Ingress:     localhost
Port:                     http  80/TCP
TargetPort:               http/TCP
NodePort:                 http  31156/TCP
Endpoints:                10.1.0.146:80
Port:                     https  443/TCP
TargetPort:               https/TCP
NodePort:                 https  31258/TCP
Endpoints:                10.1.0.146:443
Session Affinity:         None
External Traffic Policy:  Local
HealthCheck NodePort:     30297
Events:                   <none>
```

Esta salida confirma:
* **LoadBalancer Ingress: localhost** → En entornos locales, _kind_ crea un proxy que escucha en `127.0.0.1`.
* **External Traffic Policy: Local** → El tráfico externo se dirige solo a nodos que tienen un pod del controller, evitando un salto extra pero requiriendo que el pod esté presente en cada nodo expuesto.
* Los **NodePorts 31156/31258** son los que realmente reciben el tráfico en los nodos y se mapean a los puertos 80/443 dentro del pod NGINX.

```bash
# Paso 1 – ¿qué IP usar?
# ----------------------------------
# • Minikube     → $(minikube ip)
# • kind         → localhost (el NodePort se publica en tu host)
# • Docker Desk. → localhost
# • VM bare‑metal → IP del nodo mostrada en `kubectl get nodes -o wide` (columna INTERNAL-IP)
#
# Si ves una IP como 192.168.65.3 (bridge de Docker), esa dirección solo es válida dentro de
# la red interna de los contenedores; tu navegador/terminal en la máquina anfitriona no podrá
# alcanzarla.  Usa `localhost` o la IP real del host.

NODE_IP=localhost   # ← ajusta según tu plataforma
NODE_PORT=31156     # HTTP (según el Service)

curl -H "Host: app1.example.com" http://$NODE_IP:$NODE_PORT
curl -H "Host: app2.example.com" http://$NODE_IP:$NODE_PORT
```

> **Si aún falla (timeout):**
> 1. Verifica que el puerto esté escuchando: `ss -lntp | grep 31156` (Linux) o `netstat -ano | find "31156"` (Windows).
> 2. Confirma que el *endpoint* existe: `kubectl get endpoints app1-service -n app1`.
> 3. Como alternativa, usa _port‑forward_ temporal:  
>    ```bash
>    kubectl port-forward -n app1 svc/app1-service 8080:80
curl http://localhost:8080
# → Hello from App1

# Port‑forward para App2 en otro terminal o tras cerrar el anterior
kubectl port-forward -n app2 svc/app2-service 8081:80
curl http://localhost:8081
# → Hello from App2


> **Nota:**
> * En *kind* sobre Docker Desktop, también puedes usar `localhost` como `NODE_IP`.
> * Si habilitaste HTTPS, el puerto sería `31258` y necesitarías `curl -k https://$NODE_IP:31258` para ignorar TLS self‑signed.

**Qué ocurre internamente?**

1. NGINX escucha en `$NODE_PORT`.
2. Inspecciona la cabecera `Host`.
3. Aplica la regla `host: app1.example.com`.
4. Hace *proxy\_pass* al ClusterIP `app1-service`.

### 4.3 Diagnóstico rápido

| Síntoma                       | Comando                            | Interpretación                  |
| ----------------------------- | ---------------------------------- | ------------------------------- |
| `404 Not Found`               | `kubectl describe ingress ...`     | Ruta/host no coinciden.         |
| `curl: (7) Failed to connect` | `kubectl get svc -n ingress-nginx` | El NodePort/IP no es accesible. |
| `502 Bad Gateway`             | `kubectl logs <ingress-pod>`       | Servicio backend sin endpoints. |

---

## 5. Resumen y Reflexiones

Has construido un **gateway HTTP unificado** para dos microservicios, aprendiendo a:

- Declarar reglas *host/path* desacopladas del código.
- Exponer servicios internos sin abrir múltiples puertos externos.
- Adaptar la estrategia según el entorno (nube vs. local).

> **Desafío extra:** Habilita TLS autogestionado con [cert‑manager](https://cert-manager.io/) y LetsEncrypt.

---

## 6. Comandos clave y propósito

```bash
kubectl apply -f <file>           # Crear/actualizar recursos
kubectl get pods -n <ns>          # Estado de workloads
kubectl get svc  -n <ns>          # Puertos/IPs de servicios
kubectl describe ingress <name>   # Ver reglas efectivas
kubectl logs <pod> -n ingress-nginx  # Debug del controller
kubectl edit svc ingress-nginx-controller -n ingress-nginx  # Cambiar tipo de servicio
```

## Apéndice A – ¿Por qué veo tres pods en el namespace `ingress-nginx`?

Al aplicar el manifiesto oficial de **NGINX Ingress Controller**, Kubernetes crea **dos *Jobs* efímeros** y **un *Deployment* permanente**:

1. **`ingress-nginx-admission-create-*`**  
   *Tipo:* Job de una sola ejecución.  
   *Propósito:* Generar los certificados TLS y el objeto `ValidatingWebhookConfiguration` necesario para el *Admission Webhook* que valida los objetos `Ingress`.

2. **`ingress-nginx-admission-patch-*`**  
   *Tipo:* Job de una sola ejecución.  
   *Propósito:* "Parchear" el webhook recién creado, inyectando el _CA Bundle_ dentro de la configuración para que el *kube‑apiserver* pueda establecer TLS mutuo.

3. **`ingress-nginx-controller-*`**  
   *Tipo:* Deployment (ReplicaSet).  
   *Propósito:* Ejecutar NGINX en modo *reverse‑proxy* y procesar las reglas `Ingress`.  Este pod es el que permanece en estado **Running**.

### ¿Por qué los Jobs aparecen como `Completed`?

Los Jobs realizan su tarea y terminan; su contenedor sale con código `0`, por eso el estado queda en **Completed** y no consume recursos adicionales.

### ¿Por qué el controller tardó ~3 minutos en pasar de `ContainerCreating` a `Running`?

| Fase interna | Qué sucede | Fuente típica de latencia |
|--------------|-----------|---------------------------|
| **Pulling image** | Descarga `k8s.gcr.io/ingress-nginx/controller:<tag>` | Ancho de banda limitado, proxy corporativo, imagen (~100 MB). |
| **Creating container** | Kubelet crea cgroup, asigna red y monta volúmenes (incluye Secret TLS) | I/O del nodo, contención de disco. |
| **Readiness Probe** | NGINX expone `/healthz`; el pod no se marca *Ready* hasta que responde 200 | CPU saturada o configuración lenta. |

En un clúster local o con red doméstica, entre 2‑4 min es razonable.  Si excede 5 min, inspecciona eventos y logs:

```bash
kubectl describe pod <controller-pod> -n ingress-nginx   # Eventos detallados
docker logs <node‑id> | grep ingress-nginx               # Si usas containerd, reemplaza docker por crictl
```

## 7. Limpieza de recursos

Una vez verificada la funcionalidad, libera los objetos creados para mantener tu clúster ordenado y evitar consumo innecesario de recursos.

| Objetivo | Comando | Notas |
|----------|---------|-------|
| Eliminar Ingress | `kubectl delete -f app1-ingress.yaml -f app2-ingress.yaml` | El *controller* seguirá activo hasta que lo borres explícitamente. |
| Eliminar Services y Deployments | `kubectl delete -f app1-service.yaml -f app1-deployment.yaml -f app2-service.yaml -f app2-deployment.yaml` | Los *Endpoints* asociados desaparecen automáticamente. |
| Borrar Namespaces de prueba | `kubectl delete namespace app1 app2` | Esto elimina cualquier objeto restante dentro de esos namespaces. |
| Cerrar port‑forward activos | **Ctrl‑C** en la terminal donde se ejecutan | Verifica con `ps` que no queden procesos `kubectl port-forward`. |


---

### Referencias recomendadas

- [NGINX Ingress Controller – Docs](https://kubernetes.github.io/ingress-nginx/deploy/)
- [Kubernetes Networking Deep‑Dive – CNCF Webinars]
- [Production‑grade Ingress with cert‑manager & External‑DNS – Kelsey Hightower]

