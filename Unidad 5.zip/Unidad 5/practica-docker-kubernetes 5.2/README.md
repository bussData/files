
---

## Objetivo de la práctica

En Kubernetes, un *namespace* es un “sub‑clúster lógico” que le permite aislar, organizar y administrar grupos de recursos dentro de un mismo clúster físico. Gracias a los namespaces usted puede 🤝 

1. **Segregar entornos** (dev, test, prod) sin necesidad de clústeres separados.  
2. **Aplicar políticas específicas** (RBAC, NetworkPolicies, ResourceQuotas) a un subconjunto de objetos.  
3. **Evitar colisiones de nombres**: un `Service` llamado `backend` puede existir en varios namespaces simultáneamente.  
4. **Facilitar la multitenencia** al dar a cada equipo su propio “espacio de juego” controlado.  

---

## Paso 1. Inspeccionar los namespaces existentes

```bash
kubectl get namespaces          # o: kubectl get ns
```

### ¿Qué vemos y por qué?

| Columna | Significado |
|---------|-------------|
| **NAME** | nombre del namespace |
| **STATUS** | `Active` (acepta objetos) o `Terminating` (en eliminación) |
| **AGE** | tiempo desde su creación |

Salidas típicas:

```text
NAME              STATUS   AGE
default           Active   24d
kube-system       Active   24d
kube-public       Active   24d
kube-node-lease   Active   24d
```

- **default** → donde aterrizan los objetos si no se indica namespace. Úselo solo para pruebas rápidas.  
- **kube-system** → control plane: CoreDNS, kube‑proxy, etc. No toque nada aquí.  
- **kube-public** → lectura pública; Kubernetes lo reserva para info “global” (por ej., el `cluster-info` ConfigMap).  
- **kube-node-lease** → almacena objetos *Lease* que cada nodo renueva periódicamente; agiliza el *node heartbeat* y reduce la carga del API server 

> **Tip pro**: Si solo quiere los nombres, añada `-o custom-columns=NAME:.metadata.name --no-headers` 

---

## Paso 2. Crear el namespace **development**

### 2.1 Enfoque imperativo

```bash
kubectl create namespace development
```

Salida esperada:

```text
namespace/development created
```

### 2.2 Verificación

```bash
kubectl get ns
```

El nuevo namespace aparecerá con `STATUS=Active`.

#### Por qué importa el nombre  
Use nombres **cortos, significativos y estables** (p. ej. `dev`, `qa`, `prod`). Nombres coherentes facilitan RBAC y políticas 

---

## Paso 3. Desplegar un *Deployment* en el namespace

1. Cree el manifiesto `nginx-development.yaml` (note el campo `namespace`):

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
  namespace: development     # <- ubicación lógica
spec:
  replicas: 2                # Alta disponibilidad básica
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:latest  # imagen oficial
        ports:
        - containerPort: 80
```

**Línea por línea**  
- `replicas: 2` crea dos Pods idénticos para balancear carga y tolerar fallos.  
- `selector` + `template.metadata.labels` deben coincidir (Regla de oro del Deployment).  
- `containerPort` declara el puerto que escucha NGINX dentro del contenedor; *no* expone nada aún.

2. Aplique el manifiesto:

```bash
kubectl apply -f nginx-development.yaml
```

Salida:

```text
deployment.apps/nginx-deployment created
```

3. Compruebe:

```bash
kubectl get deployments -n development
```

Ejemplo:

```text
NAME               READY   UP-TO-DATE   AVAILABLE   AGE
nginx-deployment   2/2     2            2           10s
```

> **¿Por qué READY es 2/2?** Porque el ReplicaSet generó dos Pods y ambos pasaron sus *readiness probes*.

---

## Paso 4. Crear un *Service* para exponer el Deployment

Manifiesto `nginx-service.yaml`:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: nginx-service
  namespace: development
spec:
  selector:
    app: nginx           # enlaza con los Pods etiquetados
  ports:
  - protocol: TCP
    port: 80             # puerto “virtual” dentro del cluster
    targetPort: 80       # puerto real del contenedor
  type: ClusterIP        # accesible solo dentro del cluster
```

> **ClusterIP** es la opción por defecto y crea una IP virtual estable.  
> Cambie a `NodePort` o `LoadBalancer` si necesita acceso externo.

Aplicar y verificar:

```bash
kubectl apply -f nginx-service.yaml
kubectl get services -n development
```

Salida típica:

```text
NAME            TYPE        CLUSTER-IP      PORT(S)   AGE
nginx-service   ClusterIP   10.96.123.245   80/TCP    6s
```

---

## Paso 5. Inventario completo del namespace

```bash
kubectl get all -n development
```

Ejemplo de salida (columnas AGE variarán):

```text
NAME                                    READY   STATUS    RESTARTS   AGE
pod/nginx-deployment-5f8d6f7d75-8x2bf   1/1     Running   0          2m
pod/nginx-deployment-5f8d6f7d75-mz7wq   1/1     Running   0          2m

NAME                       TYPE        CLUSTER-IP      PORT(S)   AGE
service/nginx-service      ClusterIP   10.96.123.245   80/TCP    2m

NAME                               READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/nginx-deployment   2/2     2            2           2m

NAME                                          DESIRED   CURRENT   READY   AGE
replicaset.apps/nginx-deployment-5f8d6f7d75   2         2         2       2m
```

Para listar ConfigMaps y Secrets (no hemos creado ninguno, pero es buena práctica):

```bash
kubectl get configmaps,secrets -n development
```

---

## Resultado esperado y entregables

- **Captura 1**: `kubectl get ns` mostrando los namespaces por defecto + `development`.  
- **Captura 2**: contenido de `nginx-development.yaml`, comando `kubectl apply -f …` y `kubectl get deployments -n development`.  
- **Captura 3**: contenido de `nginx-service.yaml`, creación del Service y verificación.  
- **Captura 4**: `kubectl get all -n development` evidenciando Pods, ReplicaSet, Deployment y Service.  

Con esto demuestra dominio de:  
- Concepto y utilidad de los namespaces.  
- Flujo **imperativo** (`kubectl create`) vs **declarativo** (`kubectl apply`).  
- Despliegue coherente de aplicaciones multirréplica y su exposición interna.  

## 6. Limpieza — borrar el namespace “development”

```bash
kubectl delete namespace development
```
