
---

## Introducción y Objetivo de la Práctica

El objetivo principal de esta práctica es dominar la configuración de Ingress Controllers en Kubernetes mediante la creación y aplicación de archivos YAML. En concreto, se busca:

- **Consolidar y optimizar la gestión del tráfico:** En entornos productivos, es común tener múltiples aplicaciones o microservicios. Un Ingress Controller permite centralizar el control de acceso y dirigir el tráfico HTTP a los servicios correspondientes basándose en la URL y el host, lo que mejora la escalabilidad y la seguridad del clúster.
  
- **Definir reglas de tráfico precisas:** Al escribir un YAML específico, se establece que las solicitudes a determinadas rutas (por ejemplo, `/app1` o `/app2`) se redirijan a los servicios correspondientes (como `app1-servicio` y `app2-servicio`).

- **Fomentar buenas prácticas de infraestructura como código:** La práctica refuerza el uso de archivos YAML para definir la infraestructura de forma declarativa, facilitando el versionamiento, la reproducibilidad y la automatización.

Este ejercicio es fundamental para comprender cómo se abstrae la complejidad del balanceo de carga y la redirección del tráfico en Kubernetes, elementos críticos en entornos de producción.

---

## Paso 1. Eliminar Recursos Previos (si existen)

Si ya has creado recursos en una ejecución anterior, conviene eliminarlos para comenzar desde cero:

```bash
kubectl delete ingress multi-host-ingress
kubectl delete deployment app1-servicio app2-servicio
kubectl delete svc app1-servicio app2-servicio
```

---

## Paso 2. Crear los Deployments

Desplegamos dos aplicaciones de prueba (usando nginx para ambas):

```bash
kubectl create deployment app1-servicio --image=nginx
kubectl create deployment app2-servicio --image=nginx
```

Verifica que los pods se encuentren en ejecución:

```bash
kubectl get pods
```

La salida debería mostrar algo similar a:

```
NAME                             READY   STATUS    RESTARTS   AGE
app1-servicio-664db69495-xxxxx   1/1     Running   0          10s
app2-servicio-56c8b7c588-yyyyy   1/1     Running   0          10s
```

---

## Paso 3. Exponer los Deployments con Servicios

Exponemos cada deployment para que los pods sean accesibles mediante un servicio en el puerto 8080 (redireccionando al puerto 80 del contenedor):

```bash
kubectl expose deployment app1-servicio --port=8080 --target-port=80 --name=app1-servicio
kubectl expose deployment app2-servicio --port=8080 --target-port=80 --name=app2-servicio
```

Verifica los servicios y sus endpoints:

```bash
kubectl get svc
kubectl get endpoints
```

La salida debe mostrar que tanto "app1-servicio" como "app2-servicio" están expuestos en el puerto 8080 y que tienen endpoints (con la IP de los pods y el puerto 80).

---

## Paso 4. Crear el Ingress

Crea (o edita) el archivo `multi-hosts-ingress.yaml` con el siguiente contenido. Aquí se especifica la IngressClass "nginx" y se indica la regla de reescritura para redirigir el path:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: multi-host-ingress
  annotations:
    kubernetes.io/ingress.class: "nginx"
    nginx.ingress.kubernetes.io/rewrite-target: /$2
spec:
  ingressClassName: nginx
  rules:
  - host: app1.example.com
    http:
      paths:
      - path: /app1(/|$)(.*)
        pathType: ImplementationSpecific
        backend:
          service:
            name: app1-servicio
            port:
              number: 8080
  - host: app2.example.com
    http:
      paths:
      - path: /app2(/|$)(.*)
        pathType: ImplementationSpecific
        backend:
          service:
            name: app2-servicio
            port:
              number: 8080
```

Aplica el recurso Ingress:

```bash
kubectl apply -f multi-hosts-ingress.yaml
```

Verifica la descripción del Ingress:

```bash
kubectl describe ingress multi-host-ingress
```

Deberías ver las reglas configuradas correctamente, sin errores en los endpoints y con la IngressClass "nginx" asignada.

---

## Paso 5. Probar el Ingress mediante Port-Forwarding

En tu entorno, la prueba usando el NodePort no se comportó como se esperaba. Por ello, usaremos port-forwarding para redirigir directamente el puerto 80 del pod del Ingress Controller a un puerto local (por ejemplo, 8080).

Primero, identifica el nombre del pod del Ingress Controller en el namespace `ingress-nginx`:

```bash
kubectl get pods -n ingress-nginx
```

Con base en lo que ya has visto, el pod debería llamarse similar a `ingress-nginx-controller-97689b66d-r5lxr`. Ahora, realiza el port-forward:

```bash
kubectl port-forward -n ingress-nginx ingress-nginx-controller-97689b66d-r5lxr 8080:80
```

Con el port-forward activo, abre otra terminal y prueba las rutas con curl:

- Para app1:
  ```bash
  curl -H "Host: app1.example.com" http://127.0.0.1:8080/app1
  ```

- Para app2:
  ```bash
  curl -H "Host: app2.example.com" http://127.0.0.1:8080/app2
  ```

La respuesta debería ser la página por defecto de nginx (ya que ambos deployments usan la imagen de nginx). Esto confirma que el Ingress está redirigiendo correctamente el tráfico hacia los servicios backend.

---

## Para limpiar los recursos creados en la práctica, puedes ejecutar los siguientes comandos:

```bash
kubectl delete ingress multi-host-ingress
kubectl delete deployment app1-servicio app2-servicio
kubectl delete svc app1-servicio app2-servicio
```



## Conclusión

Esta práctica profundiza en la capacidad de definir y gestionar reglas de tráfico en Kubernetes utilizando Ingress Controllers y archivos YAML. Al eliminar configuraciones anteriores y aplicar nuevas reglas, se garantiza una infraestructura limpia y escalable. Cada comando y cada sección del YAML han sido diseñados para demostrar las mejores prácticas en la administración de clústeres, lo que es fundamental para entornos de producción.

Si se sigue correctamente cada paso, el resultado será un entorno donde las solicitudes a `http://app1.example.com/app1` y `http://app2.example.com/app2` se dirigen de forma precisa y segura a sus respectivos servicios, mejorando la gestión y el mantenimiento del tráfico de red en el clúster Kubernetes.