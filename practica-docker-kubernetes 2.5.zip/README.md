
---
# Práctica 2.5: Ejercicios Básicos en Kubernetes

Este repositorio contiene la práctica 2.5 del curso de Docker y Kubernetes, en la cual se abordan 10 puntos fundamentales para el manejo de recursos en Kubernetes. A través de esta práctica se aprenderá a:

- Listar y contar los Pods en namespaces críticos.
- Crear Pods de forma imperativa y declarativa (usando YAML).
- Generar manifiestos YAML utilizando la opción `--dry-run`.
- Crear y gestionar namespaces para aislar entornos.
- Desplegar un ReplicaSet que garantice la ejecución de un número definido de réplicas.
- Eliminar Pods y observar la autorreparación de un ReplicaSet.
- Crear un Deployment que administre réplicas, exponga puertos y mantenga activo el contenedor.

Cada uno de los 10 puntos de la práctica está documentado en un archivo Markdown independiente (2.5.1.md hasta 2.5.10.md) que explica en detalle el comando ejecutado, la salida y el comportamiento esperado.

Los archivos YAML necesarios (podsP3.yaml, replicaset.yaml y backend-deployment.yaml) se encuentran en este repositorio para facilitar la recreación de los ejercicios.

Este repositorio sirve como material de referencia y guía para aprender y practicar la administración de recursos en Kubernetes.

A continuación se presenta la estructura completa del repositorio (comprimido) que puedes utilizar para el proyecto, junto con el contenido de cada archivo. Puedes crear una carpeta llamada, por ejemplo, `practica-docker-kubernetes`, e incluir los siguientes archivos:

---

### Estructura del Repositorio

```
practica-docker-kubernetes/
├── 2.5.1.md
├── 2.5.2.md
├── 2.5.3.md
├── 2.5.4.md
├── 2.5.5.md
├── 2.5.6.md
├── 2.5.7.md
├── 2.5.8.md
├── 2.5.9.md
├── 2.5.10.md
├── backend-deployment.yaml
├── alpine-pod.yaml
├── podsP3.yaml
├── README.md
└── replicaset.yaml
```

---